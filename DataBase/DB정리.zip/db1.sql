
-- RDBMS(Relational Database Management System)
-- -> 관계형 데이터 베이스 관리 시스템 
-- MySQL, Oracle, MS-SQL....

-- RDBMS에서는 모든 데이터를 Relation(Table)으로 다룸
-- Table은 행과 열로 이루어진 데이터 
-- root 계정 : 관리자 계정 
-- 사용자 계정은 직접 만들어서 사용


-- 사용자(user)를 확인하는 명령어 (알아두기) ★★★★
-- 사용자를 DB에서는 계정(account)이라고 함
select user();

-- 현재 창은 root 계정임
-- 1. root 계정에서 사용자 계정을 생성
-- 1-1. 계정 생성
-- % : 모든서버
create user test01@'%' identified by '1234';
-- 1-2. 권한 부여 
-- *.* : 모든 데이터베이스.모든테이블, 데이터베이스명.테이블명 
grant all on *.* to test01@'%' with grant option;
-- 1-3. 확정
commit;

select user();




























 



