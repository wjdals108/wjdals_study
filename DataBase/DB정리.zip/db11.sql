
use db01;
select database();
show tables;

-- < 제약조건을 설정하여 테이블 생성 및 제약조건 확인>
-- empm, dept 테이블 생성
-- < 테이블 간의 관계 설정 >
-- emp 테이블의 dno 컬럼은 dept 테이블의 dno 컬럼을 참조하도록 설정  
-- foreign key가 참조하는 컬럼은 반드시 primary 키어야 한다.
-- dept 테이블 :부모 테이블, dno : primary key
-- emp 테이블 : 자식테이블,	 eno : primary key , dno : foreign key 설정 

-- 1. dept 테이블 생성 후 데이터 추가
create table dept(
dno int primary key,
dname varchar(20),
loc varchar(20)
);

-- Control + shift +Enter = 다 같이 실행 
insert into dept values(10,'ACCOUNTING','NEW YORK');
insert into dept values(20,'RESEARCH','DALLAS');
insert into dept values(30,'SALES','CHICAGO');
insert into dept values(40,'OPERATIONS','BOSTON');

desc dept;
select * from dept;

-- 2. emp테이블 생성 및 데이터 추가(참조 무결성을 설정) 
create table emp (
eno int primary key ,
ename varchar(20) not null,
job varchar(20) not null,
manager int,
hiredate date,
salary int,
commission int,
dno int,
foreign key(dno) references dept(dno)
);

desc emp;
select * from emp;

-- 정보확인
--  1번 : 각 테이블별 정보 
show index from dept;
show index from emp;

-- 2번 : 모든 정보
-- DB에 설정된 모든 제약조건 정보
select * from information_schema.table_constraints
where constraint_schema = 'db01';


-- table에 설정된 모든 제약조건 정보 확인
select * from information_schema.table_constraints
where table_name in ('emp','dept');

-- 1. 참조무결성의 확인
-- emp 테이블에 데이터를 추가하면서 제약조건 확인
-- 성공
insert into emp values(7000,'이익준','간담췌의과',9900,'2020-03-12',8800,3000,20);

-- 실패 : dept 테이블 dno 컬럼에는 50번 부서가 없기 때문
-- 자식 테이블인 emp의 dno컬럼은 외래키로써 부모 테이블인 dept의 dno 컬럼을 참조하고 있기 때문이다.
-- error : Cannot add or update a child row : a foreign key constraint fails
-- CONSTRAINT : 'emp_ibfk_1' FOREIGN KEY('dno') REFERENCES 'dept'('dno')
insert into emp values(7100,'김준완','흉부외과',9900,'2010-05-25',7700,4000,0);

select * from emp;

-- 2. 참조 무결성의 확인 
-- 부모 테이블인 dept 테이블 데이터를 삭제
-- 실패 : 부모 테이블인 dept를 참조하는 자식 테이블인 emp의 데이터에 dno가 20번인 데이터가 있기 때문 
delete from dept where dno = 20;

-- 먼저 emp 테이블에 dno = 20번인 데이터를 삭제하고나서, dept테이블 dno가 20번인 데이터를 삭제
delete from emp where eno = 7000;
select * from emp;

-- 성공 : 자식 테이블인 emp에 dno가 20번인 데이터가 없으므로, 부모테이블인 dept의 dno가 20번인 데이터가 삭제됨.
delete from dept where dno = 20;

-- < emp 테이블의 foreign key 삭제 > 
alter table emp drop foreign key emp_ibfk_1;

-- table에 설정된 모든 제약조건 정보 확인
select * from information_schema.table_constraints
where table_name in ('emp','dept');

----------------------------
----------------------------
----------------------------
-- 뷰(View) : 가상 테이블 
-- 1. 하나 이상의 테이블 또는 뷰를 이용하여 생성되는 가상의 테이블
-- 2. 실질적으로는 데이터를 저장하지 않음, 단지 쿼리문으로만 존재

-- < 뷰를 사용하는 장점 >
-- 1. 보안
-- 전체 데이터가 아닌 일부 데이터만 접근 할 수 있는 뷰를 제공.
-- 일반 사용자에게 해당 뷰만 접근하게함으로써, 중요한 데이터가 노출되는 것을 막을 수 있다.
-- 2. 사용의 편의성
-- 복잡한 쿼리문을 단순하게 만들어줌.
show tables;

create table department(
dno int primary key,
dname varchar(20),
loc varchar(20)
);

insert into department values(10,'ACCOUNTING','NEW YORK');
insert into department values(20,'RESEARCH','DALLAS');
insert into department values(30,'SALES','CHICAGO');
insert into department values(40,'OPERATIONS','BOSTON');

create table employee (
eno int primary key ,
ename varchar(20) not null,
job varchar(20) not null,
manager int,
hiredate date,
salary int,
commission int,
dno int,
foreign key(dno) references department(dno)
);


INSERT INTO employee VALUES (7369,'SMITH','CLERK',7902,'1990-12-17',800,NULL,20);
INSERT INTO employee VALUES (7499,'ALLEN','SALESMAN',7698,'1991-2-20',1600,300,30);
INSERT INTO employee VALUES (7521,'WARD','SALESMAN',7698,'1991-2-22',1250,500,30);
INSERT INTO employee VALUES (7566,'JONES','MANAGER',7839,'1991-4-2',2975,NULL,20);
INSERT INTO employee VALUES (7654,'MARTIN','SALESMAN',7698,'1991-9-28',1250,1400,30);
INSERT INTO employee VALUES (7698,'BLAKE','MANAGER',7839,'1991-5-1',2850,NULL,30);
INSERT INTO employee VALUES (7782,'CLARK','MANAGER',7839,'1991-6-9',2450,NULL,10);
INSERT INTO employee VALUES (7788,'SCOTT','ANALYST',7566,'1997-7-13',3000,NULL,20);
INSERT INTO employee VALUES (7839,'KING','PRESIDENT',NULL,'1991-11-17',5000,NULL,10);
INSERT INTO employee VALUES (7844,'TURNER','SALESMAN',7698,'1991-9-8',1500,0,30); 
INSERT INTO employee VALUES (7876,'ADAMS','CLERK',7788,'1997-7-13',1100,NULL,20);
INSERT INTO employee VALUES (7900,'JAMES','CLERK',7698,'1991-12-3',950,NULL,30);
INSERT INTO employee VALUES (7902,'FORD','ANALYST',7566,'1991-12-3',3000,NULL,20);
INSERT INTO employee VALUES (7934,'MILLER','CLERK',7782,'1992-1-23',1300,NULL,10);

-- < 뷰의 종류 > 
-- 1. 단순 뷰 : 한 개의 기본 테이블로부터 생성한 뷰 
-- 2. 복합 뷰 : 두 개 이상의 기본 테이블로부터 생성한 뷰 

-- < 단순 뷰 생성 >
-- 직무가 'SALESMAN'인 사원의 사번, 사원명, 부서번호, 직무를 출력하는 뷰를 생성하시오.
-- 장점 : 확인하고자 하는 컬럼의 내용만으로 구성된 뷰를 생성하여 사용할 수 있음.
create view v_emp_salesman(eno, ename, dno, job)	-- 괄호 안의 이름은 다르게 써도 가능하다.
as 
select eno, ename, dno, job from employee
where job = 'SALESMAN';

desc v_emp_salesman;
select * from v_emp_salesman;


-- < 단순 뷰 생성 > 
-- 장점 : 개인적인 정보(입사일, 연봉, 성과급)이 외부에 공개되는 것을 막을 수 있음.
-- 사원 테이블에서 개인정보(입사일,연봉,성과급)를 제외한 사번, 사원명, 직무, 관리자 ,부서번호를 확인할 수 있는 뷰를 생성하시오.

create view v_emp_public
as
select eno,ename,job,manager, dno from employee;

select * from v_emp_public;



-- < 복합 뷰 생성 >
-- 장점 : 복잡한 조인 쿼리로 질의를 해야 결과를 얻을 수 있었는데, 이것을 뷰로 생성해두면 간단하게 정보를 확인.
-- employee 테이블과 department 테이블의 모든 필드를 가진 뷰를 생성하시오.

create view v_emp_dept		-- 다 가지고 올때는 안 적어도 됨
as
select eno, ename, job,manager,hiredate,salary,commission, e.dno, dname,loc
from employee e, department d 
where e.dno = d.dno;

desc v_emp_dept;
select * from v_emp_dept; 

-- 뷰의 생성 확인
show tables; -- 테이블과 뷰의 정보를 확인 (뷰와 테이블의 구분이 되지 않는다.)
show full tables; -- 테이블과 뷰의 정보를 구분하여 확인 가능.

---------------------
desc v_emp_salesman;
select * from v_emp_salesman;

-- 뷰에 데이터를 추가 

-- 뷰에 데이터를 추가하면 실제로는 뷰가 참조하는 기본 테이블에 데이터가 추가 된다.
insert into v_emp_salesman values (8001,'TOM',30,'SALESMAN');
select * from v_emp_salesman; -- 뷰를 통해 확인
select * from employee;		  -- 기본 테이블을 통해 확인


-- 문제점 : 'SALESMAN'의 정보를 확인하는 뷰를 통해 'MANAGER'의 정보를 추가하는 옳지 않은 방법
-- 해결 : 'SALESMAN'의 정보를 확인 하는 뷰를 통해서는 'SALESMAN'의 정보만 추가도록 하고,
--  다른 직무의 정보를 추가하는 것은 막아야함.
insert into v_emp_salesman values (9001,'CAT',40,'MANAGER');
select * from v_emp_salesman;
select * from employee;

-- v_emp_salesman 뷰를 삭제하고, 'SALESMAN'의 정보만 추가할 수 있는 뷰를 생성  
-- 기본 테이블의 조건절에 'with check option'을 사용하면, 조건절에 해당하는 내용만 추가, 수정할 수 있다.
drop view v_emp_salesman;
show full tables;

create view v_emp_salesman (eno, ename, dno, job)
as
select eno,ename,dno,job from employee
where job = 'SALESMAN' with check option;

show full tables;
desc v_emp_salesman;
select * from v_emp_salesman;

-- 실패 : 뷰의 조건에 직무가 'SALESMAN'인 데이터만 조회하도록 하고,
-- with check option 이라는 옵션을 사용하여 다른 직무를 추가 또는 수정하는 것을 막도록 함. 
-- error : CHECK OPTION failed 'db01.v_emp_salesman'
insert into v_emp_salesman values (9001,'CAT',40,'MANAGER');


-- 문제) 사번, 사원명, 직무, 관리자, 연봉을 확인하는 뷰를 생성하시오.
create view v_emp01		-- 똑같이 가져올거 같으면 안써도 상관없음
as
select eno,ename,job,manager,salary from employee;

desc v_emp01;
select * from v_emp01;

-- 존재하는 뷰를 제거하고 새롭게 생성

create or replace view v_emp01		-- or replace 있다면 제거하고 새롭게 생성 !!
as
select eno,ename,job,manager,salary,commission from employee;
desc v_emp01;
select * from v_emp01;

show tables;
rename table board2 to board;

desc board;

-- 존재하는 테이블을 삭제하고 새롭게 생성 
drop table if exists board;

create table board(
id int primary key,
name varchar(30) not null,
subject varchar(100) not null,
content text not null
);

show full tables;

--------------
-- < 뷰 응용 문제 > 
-- 문제1) 직무가 'MANAGER'인 사원의 사번, 사원명, 부서번호, 직무를 v_emp_manager 뷰를 생성하시오.
-- 이 뷰를 통해서는 'MANAGER'가 아닌 사원은 추가 할수 없음 , 설정하고 확인하시오.
create or replace view v_emp_manager
as
select eno,ename,dno,job from employee
where job = 'MANAGER' with check option;

-- 문제확인 
show full tables;
desc v_emp_manager;
select * from v_emp_manager;

-- 성공
insert into v_emp_manager values(8002, 'MARY', 30, 'MANAGER');
select * from v_emp_manager; -- 뷰를 통해 확인
select * from employee; 	-- 기본 테이블을 통해 확인

-- 실패
insert into v_emp_manager values(9002, 'ROBERT', 30, 'ASALUST');
select * from v_emp_manager; -- 뷰를 통해 확인
select * from employee; 	-- 기본 테이블을 통해 확인


-- 문제2) 연봉이 1500에서 2500사이인 사원의 모든 정보를 확인하는 v_emp_salary 뷰를 생성하시오.
-- 이 뷰를 통해서는 salary가 1500에서 2500사이인 사원만 추가 되도록  설정하고 확인하시오.
create or replace view v_emp_salary
as
select * from employee
where salary between 1500 and 2500 with check option;

-- 문제 확인 
show full tables;
desc v_emp_salary;
select * from v_emp_salary;

-- 성공
insert into v_emp_salary (eno, ename,job,salary)
values(8003,'Tim','MANAGER',2000);
select * from v_emp_salary; -- 뷰를 통해 확인
select * from employee; 	-- 기본 테이블을 통해 확인

-- 실패
insert into v_emp_salary values(1234 ,'IU','MANAGER',4444,'1994-02-04',5000,100,20);
select * from v_emp_salary; -- 뷰를 통해 확인
select * from employee; 	-- 기본 테이블을 통해 확인

-------
-- < 뷰를 사용하는 궁극적인 장점 >
-- 여러 테이블을 다양한 함수들을 사용하여 쿼리문을 뷰로 저장하기 때문에 뷰를 간편하게 사용할 수 있음.
-- 뷰의 컬럼이 알리아스와 함수들을 통해 생성됨. -> 뷰를 통해 추가 불가 

create or replace view v_emp_salary2
as
select eno'사번',ename '사원명',job '직무',salary '연봉',
salary+ifnull(commission,0) '총 연봉' , round((salary+ifnull(commission,0))/12 , 2)  '월급'
from employee;

desc v_emp_salary2;
select * from v_emp_salary2;

-- 뷰를 통해 수정 : 'SMITH' 사원의 연봉을 4000으로 수정 
-- 실패 : 뷰의 컬럼이 기본테이블에서 가져온 알리아스로 구성되어 있기 때문.
update v_emp_salary2
set salary = 4000
where enmae = 'SMITH';


-- 성공 : 뷰의 컬럼이 기본테이블에서 가져온 알리아스로 구성되었을 때는, 알리아스를 통해 수정해야 함.
update v_emp_salary2
set 연봉 = 4000
where 사원명 = 'SMITH';
select * from v_emp_salary2;
select * from employee;



-- < 뷰를 확인하는 여러 가지 방법 >
show tables;		-- 테이블과 뷰를 구분하지 않고 확인
show full tables;   -- 테이블과 뷰를 구분하여 확인
show full tables where table_type = 'BASE TABLE'; -- 테이블만 확인
show full tables where table_type = 'VIEW';		  -- 뷰만 확인 

desc v_emp_salary2; 	-- 뷰의 구조를 확인 
check table v_emp_salary2;	-- 뷰의 정보를 확인 

-- < 기본 테이블을 삭제 하면, 뷰는 존재하지만 사용은 불가능함.>
show full tables;

drop table employee;
show full tables;	-- 뷰를 확인 할수는 있지만, 사용 불가 
check table v_emp_salary2 ;	-- 뷰의 정보를 확인, 뷰의 사용 가능 상태에 에러 정보를 확인, Msg_type 컬럼에 error이 발생 .

desc v_emp_salary2;
select * from v_emp_salary2;


































































 






























































































