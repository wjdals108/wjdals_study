
select user();      -- 사용자확인
show databases;     -- 모든 데이터베이스 보기 
use db01; 		    -- db01을 사용하겠다.
select database();	-- 사용중인 데이터베이스 확인
show tables; 		-- db01 데이터베이스안의 테이블확인!!!

-- 데이터베이스 삭제
drop database db02;

-- 사용자(계정) 삭제
drop user test02;

-- 생성된 모든 사용자(계정) 확인
use mysql;
select host, user from user;

-- 1. RDBMS(Relataional Database Management System)
-- Relataion -> Table 
-- 모든 데이터를 테이블(표) 형태로 관리하는 데이터베이스 관리 시스템 
-- 테이블은 행과 열로 구성(행(row): 데이터, 레코드 || 열(column) : 데이터 속성, 필드(field))

-- 2. SQL (Structured Query Launguage) : 구조화된 질의 언어 
-- RDBMS에서 사용하는 언어 

-- (1) DCL(Data Control Language)		: 데이터 제어어
-- grant(권한부여), revoke(권한 회수), commit(명령확정), ... 

-- (2) DDL(Data Definition Language)    : 데이터 정의어  
-- create(생성), alter(변경), drop(삭제), rename, turncate....

-- (3) DML(Data Manipulataion Language) : 데이터 조작어
-- insert(데이터 삽입), update(데이터 수정), delete(데이터 삭제), select(데이터 검색,조작)...

-----------------------------------------------------------------------------
-- (명령문은 대소문자 구분하지 않는다.)
-- (안에 들어가 있는 데이터에 대해서는 대소문자 구분한다.)
-- SQL - DML - select(SELECT)문
-- 1. select 구문 연습
-- (무조건 작성)
-- select 절 : 검색하고자 하는 열이름, *(모든컬럼,필드)
-- from 절	 : 검색하고자 하는 테이블 
-- (대괄호는 생략 가능한 절)
-- [where]	: 검색의 조건 
-- [group by 절] : 그룹을 할 열 이름 
-- [having 절] : 그룹에 대한 조건 
-- [order by 절] : 정렬하고자 하는 열 이름  

-- select와 from절은 필수 , where, group by, having, order by절은 선택 
-- 생략은 할 수 있어도 순서는 반드시 지켜야 함.

use db01;
-- employee 테이블의 모든 필드 검색 
select * from employee;

-- employee 테이블의  eno, ename, job필드 검색 
select eno, ename, job from employee;

-----------------------
-- SQL에서 사용하는 연산자
-- 1. 산술 연산자 : +, -, *, / 
-- date 타입은 +, - 사용 가능, *, / 연산자는 사용 불가 
select ename, hiredate, hiredate + 7 from employee; -- 날짜는 더하기 빼기가 가능하다 BUT 곱하기 나누기 안됨.
select ename, salary, salary -100 from employee;
select ename, salary, salary / 12 from employee;  
-- slary/12 를 월급이라는 이름으로 하고싶은데 어떡하지??

-- alias(알리아스) : 컬럼에 대한 별칭, 별명 
select ename as '사원명', salary as '연봉', salary / 12 as '월급' from employee;   -- db에서는 ""사용하지 않는다.
select ename '사원명', salary '연봉', salary / 12 '월급' from employee;  -- as는 생략도 가능하다.
select ename '사원의 이름', salary 연봉, salary / 12 월급 from employee;  -- 홀따옴표도 생략가능하지만.. 이렇게 사용하지 말자
-- 띄어쓰기,기호는 홀따옴표로 묶어야 한다 .

-- ex) 사원명 , 인상전 연봉, 인상후 * 1.2연봉
select ename '사원명', salary '인상 전 연봉', salary * 1.2 '인상후연봉' from employee;

-- ex) 사번, 사원명, 급여, 성과급, 급여+성과급을 확인 하고 싶음 
select eno, ename, salary, commission, salary + commission from employee; -- 잘못된 결과를 나타냄 !!!
-- null인 필드와의 연산의 결과는 항상 null이 됨
-- null값 어떻게 처리? table 만들때 not null이 없으면 null가능으로 인식.
-- (만들때는 정확히 만든것이 맞음 commission은 영업부만 존재하니까)
-- ifnull() : null인 필드의 값은 기본값으로 대체해주는 함수
-- <null 과 not null>
-- null과 not null
-- null :값을 입력하지 않아도 된다.
-- not null: 반드시 값을 입력해야함을 의미한다.
select eno, ename, salary, commission, salary +ifnull(commission,0) from employee; 
-- commission이 null이면 0값을 넣어라 

-- 부서번호를 검색 
select dno from employee; 			-- 중복된 값이 반복된다.
select distinct dno from employee;  -- 중복된 값은 한 번만 나온다.

-- 직무를 검색
select job from employee;			-- 중복된 값이 반복된다.
select distinct job from employee;	-- 중복된 값은 한 번만 나온다.

-- now(), sysdate() : 현재 날짜와 시간을 확인하는 함수
-- to_days() : 0년부터 ()까지의 일수를 구해주는 함수 
-- from_days() : 일수를 날짜로 변환하는 함수
select now();
select sysdate();
select to_days(now());

-- 사원명과 현재까지 사원의 근무 일수를 확인하시오.
select ename, to_days(now()) - to_days(hiredate) '근무일수' from employee;

-- 김수현이 살아온 일수를 확인 하시오. 1988년 2월 16일 
select to_days(now()) - to_days('1988-02-16');
select from_days(to_days(now()) - to_days('1988-02-16'));   -- 0032-07-03  32년 7월 3일 살았다.
select to_days(now()) - to_days('1994-02-04'); 		
select from_days(to_days(now()) - to_days('1994-02-04')) '(만)나이'; 		

-- 2. 비교 연산자 : >(크다), >=(크거나 같다), <(작다), <=(작거나 같다), =(같다), !=(같지 않다)
-- where 절 사용 
-- 문제1) 10번 부서에서 근무하는 사원의 정보를 확인하시오.
select * from employee 
where dno = 10 ;

-- 문제2) 연봉이 2500이상인 사원의 정보를 확인하시오 .
select * from employee 
where salary >= 2500; 

-- 문제3) 직무가 manager인 사원의 정보를 확인하시오
select * from employee 
where job = 'MANAGER';

-- 문제4) 부서가 10이 아닌 사원의 정보를 확인하시오.
select * from employee 
where dno != 10 ;

-- 문제5) 입사일이 1991년 7월1일 이전에 입사한 사원의 정보를 확인하시오.
select * from employee 
where hiredate < '1991-07-01' ; 






















































 
