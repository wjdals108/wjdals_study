
use db01;
show tables;		-- 데이터베이스 안의 모든 테이블명 확인
show table status;	-- 테이블에 대한 여러가지 정보 확인

-- 문제1) commission를 받는 사원의 정보를 확인하시오.
-- null 값의 비교는 연산자로 사용하지 않음. is라는 키워드를 사용 
-- is 라는 키워드와 null, not null을 사용 
-- select * from employee where commission = not null;  (에러가 뜸)
-- select * from employee where commission != null; 	결과가 없음 , 잘못된 방법
select * from employee where commission is not null;

-- 문제2) commission을 받지 않는 사원의 정보를 확인하시오.
-- select * from employee where commission = null; 결과가 없음 , 잘못된 방법
select * from employee where commission is null;

-- 문제3) 관리자가 있는 사원의 정보를 확인하시오.
select * from employee where manager is not null;

-- 문제4) 관리자가 없는 사원의 정보를 확인하시오.
select * from employee where manager is null;

-----------------------------------------------
-- 3. 논리 연산자 : and, or
-- and : 모든 조건이 참일때 전체 결과가 참 
-- or : 조건 중에 하나라도 참이 있다면, 전체 결과가 참 
-- 논리 연산의 결과 : 참(ture) 또는 거짓(false)

-- between A and B : and 연산자의 대신에 많이 사용, and보다 이걸 쓰기를 권장
-- in : or 연산자 대신에 사용, 권장 

-- 문제1) 연봉이 2000만원 이상이고, 3000만원 이하인 사원의 정보를 확인하시오.
select * from employee where salary >= 2000 and salary <= 3000 ;
select * from employee where salary between 2000 and 3000;

-- 문제2) 1997년도에 입사한 사원의 정보를 확인하시오.
select * from employee where hiredate>='1997-1-1' and hiredate<= '1997-12-31';
select * from employee where hiredate between '1997-1-1' and '1997-12-31';

-- 문제3) 직무가 'SALESMAN'이거나 'CLERK'인 사원의 정보를 확인하시오.
select * from employee where job= 'SALESMAN' or job= 'CLERK';
select * from employee where job in ('SALESMAN','CLERK');

-- 문제4) 부서번호가 10 또는 20인 사원의 정보를 확인하시오.
select * from employee where dno= 10 or dno= 20;
select * from employee where dno in (10,20);

-- 문제5) 직무가 'MANAGER'이거나 'ANALYST' 이거나 'CLERK'인 사원의 정보를 확인하시오.
select * from employee where job='MANAGER' or job='ANALYST' or job = 'CLERK';
select * from employee where job in ('MANAGER' , 'ANALYST', 'CLERK');

-- < 응용 문제>
-- 문제1) 연봉이 2000이상이고 3000만원 이하이고, 부서는 10번 또는 20번인 사원의 정보를 확인하시오.
select * from employee 
where salary between 2000 and 3000 
and dno in (10,20);

-- 문제2) 1991년 입사한 사원 중에서 직무가 'ANALYST' 또는 'MANAGER'인 사원의 정보를 확인하시오.

-- 1번 방법)
select * from employee
where hiredate >= '1991-1-1' and hiredate>='1991-12-31'
and job = 'ANALYST' or job = 'MANAGER';

-- 2번 방법)
select * from employee 
where hiredate between '1991-1-1' and '1991-12-31' 
and job in ('ANALYST','MANAGER');

-----------------------------------------
-- like 연산자 : ~을 포함하는 
-- 와일드 카드 : 특수한 목적으로 사용하는 기호 
-- % : 모든 문자, _ : 한 문자  ex) 'A_' - A로 시작하는데 두글2자 

-- 문제1) 사원이름이 A로 시작하는 사원의 정보를 확인하시오.
select * from employee where ename like 'A%';

-- 문제2) 사원이름이 S로 끝나는 사원의 정보를 확인하시오.
select * from employee where ename like '%S';

-- 문제3) 사원이름에 A가 포함되는 사원의 정보를 확인하시오.
select * from employee where ename like '%A%';

-- 문제4) 사원이름에 두번째 글자가 A인 사원의 정보를 확인하시오
select * from employee where ename like '_A%';

-- 문제5) 사원이름의 세번째 글자가 A이고, S로 끝나는 사원의 정보를 확인하시오.
select * from employee where ename like '__A%S'; -- 옳은 방법 
select * from employee where ename like '__A%' and ename like '%S'; -- 맞지만 위에 것을 권장 

-- 문제6) 1997년도에 입사한 정보를 확인하시오.
select * from employee where hiredate between '1997-01-01' and '1997-12-31';
select * from employee where hiredate like '1997%';

-- 문제7) 9월에 입사한 정보를 확인하시오.
select * from employee where hiredate like '_____09%';

-- 문제8) 입사일이 13일인 사원의 정보를 확인하시오.
select * from employee where hiredate like '%13';

---------------------
-- substring() 함수 : 문자열을 추출하는 함수, 사용하는 빈도가 높다.
-- 방법1 : substring(필드명, 몇 번째부터, 몇 글자 추출)
-- 방법2 : substring(필드명, 몇 번째부터 끝까지)

select * from employee where substring(hiredate,1,4) = '1997';   -- 문제6
select * from employee where substring(hiredate,6,2) = '09';     -- 문제7
select * from employee where substring(hiredate,9,2) = '13'; 	 -- 문제8 
select * from employee where substring(hiredate,9) = '13';       -- 9번부터 끝까지 ... 방법 2활용 

-- < substring() 함수 확인 학습 > 

-- 문제1) 사원명의 세번째 글자가 A인 사원의 정보를 확인하시오.
select * from employee where substring(ename,3,1) = 'A';
select * from employee where ename like '__A%';		-- 포함하는

-- 문제2) 1997년도에 입사한 사원이 아닌 사원의 정보를 확인하시오.
select * from employee where substring(hiredate,1,4) <>'1997';
select * from employee where hiredate not like '1997%' ;

-- 문제3) 사원명에서 세번째 글자가 A가 아닌 정보를 확인하시오.
select * from employee where substring(ename,3,1) <> 'A';
select * from employee where ename not like '___A%';	-- 포함하지 않는 

-- 문제4) 10번 부서가 아닌 사원의 정보를 확인하시오.
select * from employee where substring(dno,1,2) != 10;
select * from employee where dno <>10;
select * from employee where dno not in (10);	-- 되긴 하지만 1개있을때는 굳이 할필요 없음 !

-- 문제5) 직무가 'CLERK', 'SALESMAN'이 아닌 정보를 확인하시오.
select * from employee where job<>'CLERK' and job<>'SALESMAN';
select * from employee where job not in ('CLERK','SALESMAN');
select * from employee where substring(job,1) != 'CLERK' and substring(job,1) != 'SALESMAN';

-------------------
-- 다양한 함수 사용
-- 1. 숫자 함수 
-- round() : 반올림 함수, 숫자를 소숫점 이하에서 반올림해준다.
select round(123456.789);   -- 소숫점 첫 번째 자리에서 반올림하여 1의자리까지 표현해준다.
select round(123456.489);
select round(123456.789, 2); 	-- 소숫점 세번째 자리에서 반올림하여 소숫점 둘째자리까지 표현
select round(123456.789, 1); 	-- 소숫점 두번째 자리에서 반올림하여 소숫점 첫째자리까지 표현
select round(123456.789, -3);	-- 백의 자리에서 반올림하여 천의 자리까지 표현 
select round(123556.789, -3);
select round(123456.789, -2); 	-- 십의 자리에서 백의 자리까지 표현
select round(123456.789, -1);	-- 일의 자리에서 반올림하여 십의자리 까지표현

-- 문제) 사원번호, 사원명 , 연봉, 월급이 높은 순으로 나타내시오.
-- 연봉은 salary 와 commission을 더한 값 
-- 월급은 salary 와 commission을 더한 값에서 / 12로 나눈 값, 소수점이하 둘째까지 표현(셋째자리에서 반올림)

select eno '사원번호' , ename '사원명' , salary + ifnull(commission,0) '연봉',
round((salary + ifnull(commission,0))/12,2) '월급' from employee 
order by 4 desc;     	-- 이렇게도 가능
-- order by 월급 desc;	

-- 정렬방법 - 오름차순 정렬, 내림차순 정렬 (왼-> 오 , 위->아래 기준)
-- 오름차순 정렬 : 작은 숫자에서 큰 숫자로 정렬하는 방식
-- 내림차순 정렬 : 큰 숫자에서 작은 숫자로 정렬하는 방식 
-- order by절사용
-- 1. 필드명 사용
select * from employee order by eno; -- 기본 오름차순 정렬
select * from employee order by eno asc; -- 오름차순 , asc는 생략 가능
select * from employee order by eno desc; -- 내림차순

-- 2. 필드의 순서 번호 사용
select * from employee order by 1;    -- 필드 번호순 eno =1,ename=2,job=3 이런 느낌 
select * from employee order by 1 desc;

-- 3. 알리아스 사용		(홀 따옴표 사용 X)
select eno '사원번호', ename '사원명', job '직무' from employee order by 사원명;		
select eno '사원번호', ename '사원명', job '직무' from employee order by 사원명 desc;
  










