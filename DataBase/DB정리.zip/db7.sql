
select user();
select database();
use db01;
select database();
show tables;


-- < 3. 데이터를 삭제하는 방법 >
-- delete from : 테이블명
-- where : 조건

-- 문제1) emp1에서 직무가 'CLEAR'인 사원의 정보를 삭제하시오.
delete from emp1 where job = 'CLERK';
select * from emp1;

-- 문제2) emp1에서 직무가 'SALESMAN'이면서, 성과급이 0인 사원의 정보를 삭제하시오.
delete from emp1 where job = 'SALESMAN' and commission = 0;
select * from emp1;

-- 문제3) 1997년도 입사한 사원의 정보를 삭제하시오.
delete from emp1 where substring(hiredate,1,4) = '1997';
select * from emp1;

-- 문제4) 이름의 첫글자가 'K'인 사원의 정보를 삭제하시오.
delete from emp1 where ename like 'K%';
select * from emp1;

-- 문제5) 모든사원의 정보를 삭제하시오.
-- 주의해서 사용
delete from emp1;	-- 데이터만 모두 삭제하고, 구조는 남아있음.
select * from emp1;

-- 참고) 테이블 자체를 삭제하는 방법
drop table emp1;	-- 데이터의 데이터도 포함하여, 테이블 자체를 삭제하는 방법 


-- emp1 테이블을 employee를 복사하여 생성 (데이터도 포함)
create table emp1
as
select * from employee;
select * from emp1;

--------------------------------------
-- 조인과 서브쿼리에서 사용할 테이블 3가지
-- employee : 사원 테이블 - 사원의 정보 8가지, eno, ename, job, manager, hiredate, salary, commission, dno
-- department : 부서 테이블 - 부서의 정보 3가지, dno, dname, loc
-- salgrade = 급여 테이블 - 급여의 정보 3가지 , grade, losal , hi sal 

-- <부서 테이블>
-- 1. 부서 테이블 생성
create table department (
dno int primary key,
dname varchar(20), 
loc varchar(20)
);

desc department;
select * from department;

-- 2. 부서테이블에 데이터를 삽입 
insert into department values(10,'ACCOUNTING','NEW YORK');
insert into department values(20,'RESEARCH','DALLAS');
insert into department values(30,'SALES','CHICAGO');
insert into department values(40,'OPERATIONS','BOSTON');
select * from department;

-- < 급여 정보 테이블 > 
-- 1. 급여 테이블 생성
create table salgrade(
grade int,
losal int,
hisal int
);

-- 2. 급여 테이블에 데이터 삽입
insert into salgrade values (1,700,1200);
insert into salgrade values (2,1201,1400);
insert into salgrade values (3,1401,2000);
insert into salgrade values (4,2001,3000);
insert into salgrade values (5,3001,5000);

-------------------------

-- 조인(Join) : 결합, 연결
-- 1. 여러 테이블에 저장된 데이터를 한 번에 조회해야할 필요가 있을 때 사용.
-- 2. 두 개 이상의 테이블을 연결하여 결과를 얻는 방법



-- 문제) 사원번호가 7788인 사원의 부서의 이름을 확인하시오.
-- 이 문제는 두개의 쿼리문을 사용하여 해결하여야함.
-- 1. employee 테이블에서 사번이 7788인 사원의 부서번호를 알아낸다.
select *
from employee
where eno = 7788;
-- 2. department 테이블에서 해당 번호에 대한 부서명을 알아낸다.
select * 
from department
where dno = 20;
-- join을 사용하는 이유는 2개의 쿼리문을 1개의 쿼리문으로 해결하려고 하는 것.

-- < 조인의 종류 > 
-- 1. 크로스 조인(cross join) - 상호 조인, 대량의 데이터를 다룰 때 가끔 사용
-- 이 결과의 행은 4*14= 56건의 rows, 열은 3+8= 11 columns 
select * from department, employee;

-- 2. 이퀴 조인(equi join) : inner join과 같은 방법 
-- 실제로 가장 많이 사용하는 조인
-- 조인 대상이 되는 테이블에서 공통의 '=(equal)'비교를 통해 같은 값을 가지는 행을 연결하여 결과를 생성하는 조인 방법

-- 문제) 사번이 7788인 사원의 사원명과 부서명을 확인하시오.
-- 1번 방법 - 기본적인 방법
select employee.ename, department.dname
from employee,department
where employee.dno = department.dno -- 조인 조건 
and employee.eno = 7788;

-- 2번 방법 - 유일한 필드명은 생략 가능하다.
select ename, dname
from employee, department
where employee.dno = department.dno -- 조인 조건 
and eno = 7788;

-- 3번 방법 - 알리아스(alias)를 사용하는 방법
select  e.ename, d.dname
from employee e, department d
where e.dno= d.dno 
and e.eno = 7788;

-- 4번 방법 - 알리아스를 사용, 유일한 필드는 알리아스 생략가능 
-- 일반적으로 가장 많이 사용하는 방법
select ename, dname
from employee e, department d 
where e.dno = d.dno
and eno = 7788;

-- inner join 방법으로 해결
-- 5번 방법 - inner join의 기본 방법
select employee.ename, department.dname
from employee inner join department
on employee.dno = department.dno -- 조인조건
where employee.eno = 7788;

-- 6번 방법 - inner join, 알리아스 사용
select e.ename , d.dname
from employee e inner join department d 
on e.dno = d.dno
where e.eno = 7788;

-- 7번방법 - inner join , 알리아스 사용 , 유일한 필드는 생략 가능
-- on절에 조인 조건을 적는다.
-- 권장하는 방법
-- inner는 생략 가능
select ename , dname
from employee e inner join department d
on e.dno = d.dno
where eno = 7788;

-- equl join ,inner join 두개로 풀기
-- 문제1) 10번 부서에 속하는 사원의 부서명, 사원명, 직무를 확인하시오.
select dname, ename, job
from employee e, department d
where e.dno = d.dno
and e.dno = 10;

select dname, ename, job
from employee e inner join department d
on e.dno = d.dno
where e.dno = 10;

-- 문제2) commission을 받을 자격이 되는 사원의 사원명, 부서명, 부서지역명을 확인하시오.
select e.ename, d.dname, d.loc
from employee e, department d
where e.dno = d.dno
and commission is not null;

select ename,dname,loc
from employee e join department d
on e.dno = d.dno
where commission is not null;

-- 문제3) 'NEW YORK'에서 근무하는 사원의 사원명, 직무, 부서번호, 부서명을 확인하시오.
select ename,job,e.dno,d.dname
from employee e , department d
where e.dno = d.dno
and loc = 'NEW YORK';

select ename,job,e.dno,d.dname
from employee e inner join department d
on e.dno = d.dno
where loc = 'NEW YORK';

-- 문제4) 이름에 'A'가 포함된 사원의 사원명, 부서명을 확인하시오.
select ename, dname
from employee e ,department d
where e.dno = d.dno
and ename like '%A%';

select ename, dname
from employee e inner join department d
on e.dno = d.dno
where ename like '%A%';

------------------
-- 3. non-equl join : =(equal)을 사용하는 방법이 아닌 조인
-- 조인 조건이 특정 범위 내에 있는지를 조회하는 조인

-- 문제) 급여 테이블에서 급여의 등급을 기준으로 사원의 급여가 몇 등급에 해당하는지를 확인
-- 사원번호, 사원명 ,급여 , 급여등급을 확인하시오.
select eno, ename, salary , grade
from employee e, salgrade s 
where salary between losal and hisal;

-- 4. self join : 하나의 테이블에 있는 컬럼을 연결해서 사용하는 조인
-- 문제) 사원의 직속상관의 이름을 확인하시오. 사원번호, 사원명, 직속상관번호, 직속상관이름을 확인하시오.
-- 1번 : equi join
select e.eno, e.ename, m.eno, m.ename
from employee e, employee m
where e.manager = m.eno;	-- 조인 조건 

-- 2번 : inner join
select e.eno '사번',e.ename '사원명', m.eno '직속상관사번',m.ename'직속상관명'
from employee e inner join employee m
on e.manager = m.eno;

-- < 조인 응용 문제 >
-- 문제1) 'SCOTT'과 동일한 부서에서 근무하는 사원의 부서번호와 사원명을 출력하시오.
-- 'SCOOT'은 제외하소 출력하시오.
select e1.dno, e1.ename
from employee e, employee e1
where e.dno = e1.dno  -- 조인의 조건
and e.ename = 'SCOTT'
and e1.ename <> 'SCOTT'; -- 스캇을 빼고 싶을때 


-- 문제2) 'WARD'보다 늦게 입사한 사원의 사원명과 입사일을 확인하시오.
select s.ename, es.hiredate  
from employee s, employee o
where s.hiredate = o.hiredate
and 

















































