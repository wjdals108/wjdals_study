

-- #계정내 db리스트 확인
-- show databases;

-- 1. 사용자 확인
select user();	-- test01

-- 2. 사용중인 데이터베이스 확인
select database();

-- 3. 데이터베이스 생성
create database db01;
select database(); 

-- 4. 데이터베이스 사용
use db01;
select database();

-- 5. 테이블 생성
-- 사원 관리 테이블
-- 8개의 필드(field) : 열(column)
-- eno: 사번, ename: 사원명, job: 담당업무, manager: 직속상관사번,
-- hiredate: 입사일, salary: 연봉 , commission: 성과급, dno: 부서번호
-- primary key(기본키, 주키, PK) : 다른 행과 구별되는 유일한 필드, 
-- primary key는 두 가지의 특징(not null, unique)을 가진다.
-- ex) 학번, 사번 ...

-- not null : 반드시 입력해야함, null : 입력하지 않을 수 있음. 

create table employee (
eno int primary key,
ename varchar(20) not null,
job varchar(20) not null,
manager int,
hiredate date,
salary int,
commission int,
dno int
);

-- 6. 데이터베이스 안의 테이블 확인 
show tables;

-- 7. 테이블의 구조를 확인
desc employee;

-- 8. 테이블의 데이터를 확인 
select * from employee;

-- 9. 테이블 정보를 삽입(추가) ★★★★
insert into employee values(7369,'SMITH','CLERK',7902,'1990-12-27',800,NULL,20);

select * from employee;

-- 10. 계정에 있는 데이터베이스를 확인방법
show databases;

-- 11. 테이블의 모든 데이터 삭제 
delete from employee;

INSERT INTO employee VALUES (7369,'SMITH','CLERK',7902,'1980-12-17',800,NULL,20);
INSERT INTO employee VALUES (7499,'ALLEN','SALESMAN',7698,'1991-2-20',1600,300,30);
INSERT INTO employee VALUES (7521,'WARD','SALESMAN',7698,'1991-2-22',1250,500,30);
INSERT INTO employee VALUES (7566,'JONES','MANAGER',7839,'1991-4-2',2975,NULL,20);
INSERT INTO employee VALUES (7654,'MARTIN','SALESMAN',7698,'1991-9-28',1250,1400,30);
INSERT INTO employee VALUES (7698,'BLAKE','MANAGER',7839,'1991-5-1',2850,NULL,30);
INSERT INTO employee VALUES (7782,'CLARK','MANAGER',7839,'1991-6-9',2450,NULL,10);
INSERT INTO employee VALUES (7788,'SCOTT','ANALYST',7566,'1997-7-13',3000,NULL,20);
INSERT INTO employee VALUES (7839,'KING','PRESIDENT',NULL,'1991-11-17',5000,NULL,10);
INSERT INTO employee VALUES (7844,'TURNER','SALESMAN',7698,'1991-9-8',1500,0,30); 
INSERT INTO employee VALUES (7876,'ADAMS','CLERK',7788,'1997-7-13',1100,NULL,20);
INSERT INTO employee VALUES (7900,'JAMES','CLERK',7698,'1991-12-3',950,NULL,30);
INSERT INTO employee VALUES (7902,'FORD','ANALYST',7566,'1991-12-3',3000,NULL,20);
INSERT INTO employee VALUES (7934,'MILLER','CLERK',7782,'1992-1-23',1300,NULL,10);

























