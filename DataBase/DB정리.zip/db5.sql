select user();
select database();
use db01;
select database();

-- 문제) 사원번호, 사원명, 연봉, 월급을 높은 순으로 5명의 직원의 정보만 확인하시오.
select eno '사원번호' , ename '사원명', salary+ifnull(commission,0) '연봉', (salary+ifnull(commission,0))/12 '월급'
from employee
order by 4 desc
-- limit 5;	-- 상위 5건 
-- limit 0,5 ; 
limit 5 offset 0 ;

-- limit는 mysql에서만 사용 가능 
-- limit N : 상위 N건의 데이터를 확인
-- limit 시작,갯수
-- limit 갯수 offset 시작 

---------------------------------
-- 1. 다양한 숫자 함수 

-- truncate() : 지정한 자릿수 만큼 버림
-- select truncate(123456.789); 		-- 에러 상태 , 자릿수를 지정해야 사용 가능 
select truncate(123456.789, 2);  	-- 소숫점 둘째자리 까지 남기고 , 그 이하는 버림
select truncate(123456.789, -2); 	-- 십의 자리까지 버리고 , 백의 자리를 남김 

-- floor() : 무조건 소수점 이하를 내림
-- ceil(), ceiling() : 소숫점에서 무조건 올림
select floor(123456.789);
select floor(123456.789,2);		-- 에러가 난다 ... 자릿수를 지정 할 수 없는 함수 

select ceil(123456.789);
select ceil(123456.123);		-- 소숫점 첫째 자리에서 무조건 올림
select ceiling(12356.123);
-- ceil(), ceiling() 은 같은 함수다 ... 그냥 ceil 쓰자 !!

-- mod() : 나머지를 구함
select 10/5;		-- 3.33333
select mod(10,3);
select mod(13,5);		
 
 -- 몫을 구하는 방법 : floor() 함수를 사용 
 select floor(10/3);
 select floor(13/5);
 
 -- abs() : 절대값을 구함
 select abs(-10);
 select abs(10);
 
 -- pow(), power() :승수를 구하는 함수 
 select pow(2,3);		-- 2의 3승
 select pow(3,5);		-- 3의 5승 
 
 -- greatest() : 주어진 값 중에서 가장 큰 값
 -- least() : 주어진 값 중에서 가장 작은 값 
 -- 주의!!) DBMS에서는 max(), min()은 집계함수(집합함수)로 처리하게 됨.
 select greatest(35, 45, 97, 82, 75);	-- 97
 select least(35, 45, 97, 82, 75);		-- 35
 
 -- fromat() : 숫자의 형식을 지정해주는 함수
 -- 소숫점 자릿수를 지정해야 함, 지정한 자릿수까지 반올림해서 출력 
 -- ex) 5,123,450 (천 단위 구분기호)
 select 5123450;
 select format(5123450);	-- Error , 소숫점 자릿수를 지정해야 함.
 select format(5123450,0);	-- 5,123,450
 select format(5123450.123456,4);
 
 
-----------------------

-- 2. 문자 함수 
-- upper(), ucase(): 대문자로 변환
-- lower(), lcase() : 소문자로 변환
select upper('abcdef');
select ucase('abcdef');
select lower('ABCDEF');
select lcase('ABCDEF');

-- 문제) 사번, 사원명, 직무를 확인하시오.
-- 사원명을 소문자로 확인
select eno, lower(ename), job from employee;

-- substring() :문자열을 추출 하는 함수 , 날짜에서도 사용가능 
-- substring(필드명, 시작번호, 갯수) :시작번호에서 갯수만큼 추출 
-- substring(필드명, 시작번호) : 시작번호에서 끝까지

-- 문제) 사원의 입사일 중 입사년도를 사번, 사원명, 직무 , 입사년도를 확인하시오.
select eno, ename, job, substring(hiredate,1,4) from employee;

-- concat() : concatenate, 잇다, 통합하다, 문자열을 연결하는 함수 
select 'DBMS','-SQL';
select concat('DBMS ','-SQL');
select concat('abcd','efg','higfg','fgfgfg');

-- 문제) 사번과 사원명을 아래의 형태로 함께 출력하시오.
-- 7777(문강태)
select eno , ename from employee;
select concat(eno,'(',ename,')') '사번(사원명)' from employee;

-- concat_ws() : 구분자와 문자열을 연결
select concat('/','2020','08','20');		-- 결과 : /20200820
select concat_ws('/','2020','08','20');		-- 결과 : 2020/08/20

-- 문제) 사번, 사원명, 직무를 아래의 형태로 출력하시오.
-- ex) 7777-JAMES-MANAGER 이런형태로 ..
select concat_ws('-', eno, ename, job) from employee;

-- length() 	 : 문자열의 길이를 비트로 출력하는 함수 (영어 1비트, 한글 3비트로 취급)
-- bit_length()  : 
-- char_length() : 글자수를 출력하는 함수 (영어 , 한글 차이로 인해) char_length()이것이 정확하게 글자수의 길이를 알려준다 .
select length('Hello MySQL Wrold!!!');		-- 결과 : 20
select bit_length('Hello MySQL Wrold!!!');	-- 결과 : 160
select char_length('Hello MySQL Wrold!!!');	-- 결과 : 20

select length('데이터베이스를 배우고 있습니다');	-- 결과 : 44, 한글은 한문자가 3bit로표현 14 *3 = 42 + 2(공백)  
select bit_length('데이터베이스를 배우고 있습니다'); -- 결과 : 352
select char_length('데이터베이스를 배우고 있습니다'); -- 결과 - 16

-- left()	: 왼쪽에서 문자열의 길이만큼 문자를 반환
select left('Hello MySQL World!!',8);		-- Hello my
-- right()	: 오른쪽에서 문자열의 길이만큼 문자를 반환 
select right('Hello MySQL World!!',8);		-- World!!

-- lpad() : 왼쪽에 특정 문자를 문자열의 길이만큼 채우는 함수 
-- lpad(문자열, 문자열 전체길이, 채울 문자)
select lpad('hello', 10, '*');
-- rpad() : 오른쪽에 특정 문자를 문자열의 길이만큼 채우는 함수 
-- rpad(문자열, 문자열 전체길이, 채울 문자)
select rpad('hello', 10, '*');

-- ltrim() : 문자열의 왼쪽 공백을 제거
-- rtirm() : 문자열의 오른쪽 공백을 제거 
-- trim() : 앞뒤 공백을 모두제거
select '             데이터베이스 공부중';		-- 왼쪽 공백
select ltrim('		데이터베이스 공부 중'); -- 왼쪽 공백 제거 
select rtrim('데이터베이스 공부 중  ');    -- 오른쪽 공백 제거
select concat('데이터베이스 공부 중        ','열공');				-- 오른쪽에 5개의 공백
select concat(rtrim('데이터베이스 공부 중        '),'열공');		-- 오른쪽 공백 제거 
select concat(trim('        데이터베이스 공부 중        '),'열공');

-- repeat() : 문자열을 횟수만큼 반복
select repeat('hello',3);

-- replace() : 문자열에서 이전 문자열을 새로운 문자열로 바꿔준다.
-- replace(문자열, 이전 문자열, 새로운 문자열);
select replace('Hello DBMS World!!!', 'DBMS', 'MySQL');

-- reverse() : 문자열을 거꾸로 만들어줌
select reverse('hello');

-- space() : 길이만큼 공백을 만들어준다.
select concat('Hello',space(10),'MySQL');

-- instr() : 문자열 안에 찾는 문자의 인덱스번호를 알려준다.
select instr('Hello MySQL World!!', 'Q');	-- 10번째 있음.
select instr('Hello MySQL World!!', 'A');	-- 0, 0은 순서가 없는 번호이기 때문에 0이 나옴 

-- insert() : 문자열에서 길이 만큼을 지우고, 삽입할 문자열을 끼워 넣는 함수
-- insert(문자열, 인덱스번호, 갯수, 삽입할 문자)
select insert('abcdefghi',3,4,'####');

-- 3. 날짜 함수 
-- now(), sysdate(), localtime(), current_timestamp() : 현재 시스템의 날짜와 시간을 알려주는 함수 
-- curdate(), current_date() : 현재 날짜를 알려주는 함수
-- curtime(), current_time() : 현재 시간을 알려주는 함수 
-- date(), time() : 날짜에서 년월일, 시분초를 추출하는 함수
-- year(), month(), day(), hour(), minute(), second(), microsecond() : 날짜에서 년, 월, 일 , 시, 분 , 초, 밀리초(1/1000)을 구하는 함수 
-- dayofweek() : 날짜에서 요일을 구하는 함수, 요일을 1~7로 구해주고, 일(1)월화수목금토(7)
-- dayofmonth() : 월중에서 몇일인지를 구하는 함수 
-- dayofyear() : 1년중에서 몇일이 지났는지를 구하는 함수 
-- monthname() : 날짜의 월이름을 구하는 함수 
-- last_day() : 해당 월의 마지막 일을 구하는 함수 
-- quarter() : 날짜의 분기를 구하는 함수, 1년을 4분기로 나누었을 때 

--------

-- adddate(), subdate() : 날짜에서 차이를 더하고, 빼는 함수 
-- addtime(), subtime() : 시간에서 차이를 더하고, 빼는 함수
-- datediff(), timediff() : 날짜1-날짜2,  시간1-시간2를 구하는 함수 
-- makedate() : 연도에서 숫자만큼 지난 날짜를 생성하는 함수 
-- maketime() : 시, 분, 초를 통해 시간을 생성하는 함수 
-- period_add(), period_diff() : 년 월에서 월을 더하거나 빼는 함수 

select now();	-- 가장많이 사용, 권장 
select sysdate();
select localtime();
select current_timestamp();

select curdate(); -- 날짜만 구하는 함수 
select current_date();

select curtime(); -- 시간만 함수 
select current_time(); 

select date(now());		-- 날짜만 추출하는 함수
select time(now());		-- 시간만 추출하는 함수 

select year(now());
select month(now());
select day(now());

-- 문제) 사번, 사원명, 입사년 ,입사월, 입사일 년월일을 따로 출력 하시오.
select eno, ename, hiredate, year(hiredate), month(hiredate), day(hiredate) from employee;

-- 문제) 7월에 입사한 사원의 정보를 확인하시오.
select * from employee where month(hiredate) = '07';


select hour(now());
select minute(now());
select second(now());
select microsecond(now());	-- 확인필요

select dayofweek(now());	-- 1~7로 표현, 일:1 ~ 토:7  
-- 문제) 사원의 입사일과 요일을 구하시오.
-- 요일을 문자로 표현???? HOW 
select eno, ename, hiredate, dayofweek(hiredate) from employee;

select dayofmonth(now()); 		-- day(now()); 와 같은 결과 
select dayofyear(now());		-- 223, 1년중에서 223일째 날
select last_day(now());			-- 해당날짜의 마지막 날짜를 구해줌
select quarter(now());			-- 3분기(7,8,9월)
select monthname(now());		-- 월의 영어이름을 구해줌.

---------------------------------------

select adddate(now(), 30);		-- 날짜를 기준으로 30일 후     	(이게 가장쉬움.. 이걸로 외우자)
select adddate(now(), interval 30 day); 
-- select date_add(now(), 30);
select date_add(now(),interval 30 day);	-- 날짜를 기준으로 30일 후 	

select subdate(now(), 20);		-- 날짜를 기준으로 20일 전 	(이거 쓰자 밑에는 그냥 참고용)
select subdate(now(), interval 20 day);
-- select date_sub(now(), 20);		-- error
select date_sub(now(),interval 20 day);

select addtime(now(), '07:10:10');	-- 시간을 기준으로 '시:분:초' 후의 시간
select subtime(now(), '03:00:00');	-- 시간을 기준으로 '시:분:초' 전의 시간 

-- 문제) 사원의 근무일수를 확인하시오.
-- datediff() 날짜의 차이를 구함.
select eno, ename, hiredate, to_days(now()) - to_days(hiredate) from employee;
select eno, ename, hiredate, datediff(now(),hiredate) from employee;

-- timediff() 시간의 차이를 구함.
select timediff('2020-08-22 12:00:00', now());	-- 44:09:20, 44시간, 9분 25초가 남았다.

-- period_add(년월, 더할 월) 
-- period_diff(년월1, 년월2)	: 년월1 - 년월2
-- 연월에서 월을 더하거나 빼서 계산 
select period_add('202008',10);		-- 2020년 08월에서 10개월 후 
-- select period_add(now(),10);		error, 년월만 사용 해야함 ...
select period_add('202008',-10);	-- 2020년 08월에서 10개월 전 
select period_diff('202008','201809');	-- 23개월 

-- makedate(연도, 일수)	:연도에서 일수만큼 지난 날짜 까지 만들어짐
select makedate(2020, 10);		-- 2020-01-10
-- maketime(시,분,초) 	: 시분초를 통해 시간을 생성 
select maketime(13,33,45);		-- 13:33:45 (13시 33분 45초)





























































 
 
 
 
 
 
 
 
 
 
 
 
 



















