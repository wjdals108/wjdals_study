db6
-- 4. 집계 함수, 집합 함수 , 통계 함수 
-- sum(): 합계 , avg(): 평균, max(): 최댓값, min(): 최솟값 , count(): 갯수 	(많이쓰는 함수들)
-- stdev(): 표준편차, var_samp(): 분산 

-- 문제1) 사원수가 몇명인지를 확인하시오.
-- count() : null 값을 제외하고 갯수를 구함.
-- count(*) : 모든 갯수를 구함.
select count(eno) '사원수' from employee;		-- 14
select count(manager) from employee;  		-- 13, 잘못된 결과, null을 제외하고 갯수를 구함.
select count(commission) from employee;		-- 4,  잘못된 결과, null을 제외하고 갯수를 구함.
select count(*) from employee; 				-- 14 , 권장하는 방법 

-- 문제2) 사원 연봉의 합계와 평균을 구하시오.

select sum(salary) '연봉의 합계', round(avg(salary),2) '연봉의 평균' from employee;
select sum(salary) '연봉의 합계', format(avg(salary),2) '연봉의 평균' from employee; 

-- 문제3) 사원 연봉의 최댓값과 최솟값을 구하시오.
select max(salary) '연봉 최댓값', min(salary) '연봉 최솟값' from employee;

-- 문제4) 사원중에서 가장 최근에 입사한 사원의 입사일과 , 가장 오래 근무한 사원의 입사일을 출력하시오.
select min(hiredate) '오래일한 사원' , max(hiredate) '최근에 입사한 사원' from employee;

-- 문제5) 커미션을 받는 사원수를 구하시오. 
select count(commission) from employee;
select count(*) from employee '커미션을 받는 수' where commission is not null;  -- 두번째가 더 좋은 방법임 

-- 문제6) 직무의 수를 구하시오.
select count(job) '직무 수 'from employee;		-- 14 잘못된 답 직무가 다나옴.
select count(distinct job) '직무 수 'from employee;	-- 5 중복된 직무수 제거 해서 나옴

-- 문제7) 최고 연봉을 받는 사원의 이름과 연봉을 확인하시오.
-- mysql에서는 잘못된 결과 
-- orcale에서는 에러 
select ename '최고연봉자' , max(salary) '최고연봉금액' from employee; -- 잘못된 결과, 해결책은 서브쿼리, 조인 


----------------------
-- group by절 : 테이블에서 그룹별로 검색하고자 할때 사용하는 절  
-- having절 : 그룹에 대한 조건을 적는 절 

-- 문제1) 부서별로 평균 급여를 부서번호를 기준으로 오름차순으로 구하시오.
-- 평균급여는 소숫점 둘째자리에서 반올림하여 표시하고, 별칭을 사용하시오.
select dno '부서번호', round(avg(salary),2) '부서별평균급여'
 from employee
 group by dno
 order by dno;
 
 -- 문제2) 부서별로 인원수, 급여총액을 부서번호를 기준으로 오름차순으로 구하시오.
 select dno'부서번호', count(*)'인원수', sum(salary)'급여총액' from employee
 group by dno
 order by dno;
 
 -- 문제3) 직무별로 급여의 평균을 급여평균을 기준으로 내림차순하여 구하시오.
 -- 급여평균은 소숫점 둘째자리에서 반올림하여 표시하고, 별칭을 사용하시오
 select job '직무', round(avg(salary),2) '급여평균' from employee
 group by job
 order by 급여평균 desc;
 
 -- 문제4) 부서별, 직무별 인원수와 급여의 합계를 부서번호를 기준으로 오름차순하고, 부서가 같다면 직무를 기준으로 오름차순하여 구하시오.
 
 select dno, job, count(*), sum(salary) 
 from employee
 group by dno , job 
 order by dno , job;
 
 -- 문제5) 부서별, 급여총액이 3000이상인 부서의 부서번호, 급여총액을 구하시오.
 select dno, sum(salary)
 from employee
 group by dno
 having sum(salary) >= 3000;
 
 -- 문제6) 직무가 MANAGER인 사원은 제외하고, 직무별 급여총액이 5000이상인 직무와 급여총액을 급여총액을 기준으로 내림차순하여 구하시오.
select job, sum(salary)
from employee
where job <> 'MANAGER'
group by job
having sum(salary) >= 5000
order by 2 desc;
 
 -- 문제 7) 직무별 사원의 최저급여를 구하시오. 
 -- 관리자를 알수없는 사원과 최저급여가 2000미만인 사원은 그룹은 제외하고, 최저급여에 대하여 내림차순으로 구하시오.
select job '직무' , min(salary) '최저급여'
from employee
where manager is not null
group by job
having min(salary) >= 2000
order by 2 desc;
 
select job, min(salary)
from employee
where manager is not null
group by job
having not min(salary) < 2000
order by 2 desc;

-- 테이블 복사하는 방법  
-- 1. 테이블의 모든 컬럼과 모든 데이터를 복사 (행렬전부)
-- 중요) Primary Key 속성은 복사되지 않는다.
create table emp1
as
select * from employee;

show tables;
desc emp1;		-- 테이블의 구조확인 , 중요) Primary Key 속성은 복사되지 않는다.
select * from emp1;		-- 데이터 확인

-- 2. 테이블의 지정된 컬럼과 모든 데이터를 복사 
create table emp2
as
select eno, ename, salary from employee;

show tables;
desc emp2;
select * from emp2;

-- 3. 테이블의 모든컬럼과 조건에 맞는 데이터를 복사 
create table emp3
as
select * from employee where dno=10;

show tables;
desc emp3;
select * from emp3;

-- 4. 테이블의 모든컬럼을 포함하고, 데이터는 가져오지않고 복사
-- (테이블의 구조만 복사, 데이터없이)
create table emp4
as
select * from employee where 1 = 0 ;


show tables;
desc emp4;
select * from emp4;

-- < 데이터 삽입(추가)하는 방법 > 
-- emp4 테이블 사용 
-- 1. 추가하는 데이터와 테이블의 컬럼의 순서가 일치할 때 - 컬럼의 이름을 생략가능
insert into emp4 values(1000,'이익준','기획팀',5000,'2019-3-8',3500,null,40);
insert into emp4 values(1100,'채송화','홍보팀',6000,'2018-10-23',3200,null,30);
select * from emp4;

-- 2. 추가하는 데이터와 테이블의 컬럼의 순서가 일치하지 않을 때 - 컬럼의 이름을 생략 불가  (FM방식)
insert into emp4(eno, ename, manager, job, hiredate,salary,commission,dno)
values(1200,'양석형',7000,'관리팀','2020-11-10','3300',null,20); 

-- 아래는 에러 : manager는 int형, '관리팀'은 문자열 -> 타입 불일치 
insert into emp4(eno, ename, manager, job, hiredate,salary,commission,dno)
values(1200,'양석형','관리팀',7000,'2020-11-10','3300',null,20); 

-- 3. 추가하고자 하는 필드의 데이터만 입력할 때 
-- not null은 생략불가(무조건 입력) , null은 생략 가능
-- 에러발생 -> not null인 job은 생략이 불가함.
insert into emp4(eno,ename) values(2000,'김준완');	
-- 실행됨 -> not null인 eno, ename, job을 모두 입력했기 때문
insert into emp4(eno,ename,job) values(2000,'김준완','영업팀');	
select * from emp4;

-- <데이터를 수정하는 방법>
-- 문제1) emp4 테이블에서  '채송화'의 연봉을 4200으로 수정하시오.
-- update 절 : tabale명 
-- set 절 :	변경하고자 하는 컬럼과 값 
-- where절 : 조건이 되는 컬럼과 값 

update emp4
set salary = 4200
where ename = '채송화';

-- 문제2) emp1테이블에서 연봉이 1500 미만인 사원의 연봉을 1500으로 변경 하시오
update emp1
set salary = 1500
where salary < 1500;
select * from emp1;

-- 문제3) emp1 테이블에서 직무가 'SALESMAN'이고 , 1991년 2월 입사한 사원의 연봉을 500인상하고, commission은 200인상하시오.
update emp1
set salary = salary +500 and commission = commission +200
where job = 'SALESMAN' and hiredate < '1991-02' ; 























 
 
 
 
 

 
 
 
 
















