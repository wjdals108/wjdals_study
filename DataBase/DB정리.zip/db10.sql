
use db01;

-- < 테이블의 제약 조건 > 
-- 제약 조건 : DB의 무결성 유지를 위해서 테이블의 생성과 수정시에 지켜져야할 조건
-- 무결성 : 테이블의 데이터들이 일관성을 유지하기 위한 성질
-- 제약 조건의 종류 :
-- primary key(기본키, 주키,PK), not null, unique, default, foreign key(외래키,참조키,FK) 
-- 1. primary key : 테이블에서 유일하게 구분할 수 있는 컬럼 ex) 학번, 사번, 주민등록번호
-- primary key = not null + unique
-- 2. not null : 값이 무조건 존재해야 하는 컬럼, 값이 없으면 안됨.
-- 3. unique : 유일하게 존재해야 하는 컬럼
-- 4. default : 값이 생략되었을 때, 기본값으로 설정되는 컬럼
-- 5. foreign key : 두 테이블 사이의 관계(부모,자식)를 설정하고, 데이터의 무결성을 보장하는 제약 조건 
-- 부모 테이블 : 참조를 받는 테이블 , department
-- 자식 테이블 : 참조를 하는 테이블 , employee
-- 이러한 관계를 설정하여 무결성을 유지하는 것 --> 참조 무결성 
-- 6. check : 컬럼의 값이 특정 범위의 값일 때만 변경되도록 하는 제약 조건



-- < employee, department 테이블은 참조 무결성이 설정되지 않은 상태 > 

-- employee 테이블 부서가 50번인 사원을 추가 -> 참조 무결성을 위배
insert into employee
values(9000,'TOM','SALESMAN',7698,'1998-05-06',1500,500,50);

select * from employee;

-- 문제) 'TOM' 사원의 사원번호, 사원명, 연봉, 부서번호, 부서명, 부서지역명을 출력하시오.
-- 조인
select eno, ename, salary, e.dno, dname, loc
from employee e , department d 
where e.dno = d.dno
and ename = 'TOM';
-- 문제점 : 잘못됨, 아무 결과도 나오지 않는다.
-- 왜냐하면, department 테이블에는 50번 부서는 등록되어 있지 않기 때문
-- 이 문제를 해결하는 방법
-- 1. department 테이블 50번 부서를 등록하고 조인 쿼리를 실행하면 됨.
-- 2. 이 회사에는 50번 부서가 원래부터 없다면, 1번 방법은 해결책이 아니다.
-- 3. 최선의 해결책은 제약 조건의 설정을 통해 참조 무결성을 설정하여,
--    처음부터 부서번호가 50번인 사원은 입력되지 않도록 하여야함.

-- < 참조 무결성을 설정하여 위의 문제를 해결 > 
delete from employee where ename = 'TOM';
select * from employee;

-- 참조 무결성을 설정하려면  
-- 1. 참조하는 자식테이블의 필드가 참조하는 부모테이블의 필드는 primary key 로 설정되어야함.
-- 2. 자식테이블의 필드에는 외래키(참조키)를 설정하여야 함.

-- 제약조건을 확인
-- 1. 간결하게 확인
desc employee;
desc department;

-- 2. 자세한 정보 확인
show index from employee;
show index from department;

-- department 테이블에 dno는 primary키로 설정되어 있다.
-- employee 테이블의 dno foreign key(외래키, 참조키, FK)를 설정하여야 함.
-- employee 테이블의 구조를 변경하는 것.
-- < 외래키(참조키) 제약조건을 추가 > 
alter table employee add constraint foreign key(dno) references department(dno);

desc employee;
show index from employee;

-- 불가 : employee 테이블 dno는 department 테이블 dno 참조하여 삽입, 변경하도록 참조무결성 설정되어 삽입 불가 
-- error : Cannot add or update a child row : a foregin key constraint fail. 
insert into employee
values(9000,'TOM','SALESMAN',7698,'1998-05-06',1500,500,50);

-- 가능 : 외래키 제약조건을 위반하지 않으므로 삽입 
insert into employee
values(9000,'TOM','SALESMAN',7698,'1998-05-06',1500,500,40);


---------------------
-- < employee, department 테이블 복사본을 생성 > 
create table emp_copy
as
select * from employee;

create table dept_copy
as 
select * from department;

-- 확인 primary key , foreign 복사 x
desc emp_copy;
select * from emp_copy;

desc dept_copy;
select * from dept_copy;

-- 제약조건을 상세히 확인
show index from emp_copy;	-- 결과 없음
show index from dept_copy;	-- 결과 없음 

-- emp_copy, dept_copy 테이블 제약조건을 설정하려고 함.
-- 1. emp_copy 테이블 primary key 설정 
alter table emp_copy add constraint pk_emp_coy_eno primary key(eno);
show index from emp_copy;

-- 불가
-- 자식테이블의 외래키를 부모테이블 기본키보다 먼저 설정할 수는 없음.
-- error : Failed to add the foreign key constraint. 
-- Missing index for constraint 'emp_copy_ibfk_1' in the referenced table 'dept_copy'	0.000 sec
alter table emp_copy add constraint foreign key (dno) references dept_copy (dno);

-- 2. dept_ copy 테이블 primary key 설정
-- 부모테이블의 기본키는 자식테이블의 외래키 보다 먼저 설정 되어야 함.
alter table dept_copy add constraint pk_dept_copy_dno primary key (dno);
show index from dept_copy;

-- 3. emp_copy 테이블에서 foreign key 설정
-- key_name에 컬럼이름이 들어감.  
alter table emp_copy add constraint fk_emp_copy_dno foreign key (dno) references dept_copy(dno);
show index from emp_copy;


insert into emp_copy
values(9100,'MARK','CLERK',7902,'1995-08-15',2100,null,50);

-- < 제약조건 삭제 >
alter table dept_copy drop primary key;
show index from dept_copy;

alter table emp_copy drop primary key;
show index from emp_copy;
 
 -- foregin key 삭제시에 문제 발생 -> 해결요망 
 alter table emp_copy drop foreign key fk_emp_copy_dno;
 
 --------
 -- < unique 제약 조건 > 
 -- 유일한 값을 가지도록 하는 제약조건
 desc dept_copy;
 select * from dept_copy;
 
 -- 문제점 : 'SALES' 부서는 하나여야 하는데, 'SALES' 부서를 추가 했더니, 삽입이 되었음.
 insert into dept_copy values(50, 'SALES' ,'LA');
 select * from dept_copy;
 
 delete from dept_copy where dno = 50;
 select * from dept_copy;
 
 
 -- dname 컬럼에 < unique 제약조건 > 을 설정
 alter table dept_copy add constraint uq_dept_copy_dname unique(dname); 
 show index from dept_copy;
 
 -- 불가 : dname에 중복된 이름을 설정 삽일할 수는 없음.
 -- error : Duplicate entry 'SALES' for key 'dept_copy.uq_dept_copy_dname'
 insert into dept_copy values(50, 'SALES' ,'LA');
 
 -- NULL은 항상 unique 하다고 판단함.
 insert into dept_copy values(60,null,'SEATTLE');
 select * from dept_copy;
 
 insert into dept_copy values(70,null,'SEATTLE');
 select * from dept_copy;
 
 -- unique 제약 조건 제거 
 alter table dept_copy drop index uq_dept_copy_dname ;
 show index from dept_copy;
 
 ------------------
 -- < check 제약 조건>
 -- 컬럼의 길이 특정 범위의 값일 때만 변경되도록 하는 제약 조건 
 
 insert into emp_copy
 values(9200,'JERRY','ANALYST',7566,'1996-11-11', 6000, NULL,30);
 select * from emp_copy;

 delete from emp_copy where eno = 9200;
 -- check 제약조건을 설정 : salary의 값은 800 ~ 5000 사이의 값만 입력되도록 설정
 alter table emp_copy add constraint ck_emp_copy_salary check (salary between 800 and 5000 );
 
 -- 불가 : salary 컬럼의 값의 범위를 800 ~ 5000 사이의 값만 입력되는 check 제약조건이 설정되어 있기때문.
 -- error : Check constraint 'ck_emp_copy_salary' is violated. 
 insert into emp_copy
 values(9200,'JERRY','ANALYST',7566,'1996-11-11', 6000, NULL,30);
 
 select * from emp_copy;
 
 -- 가능 : salary 컬럼의 check 제약조건에 위배되지 않음.
 insert into emp_copy
 values(9200,'JERRY','ANALYST',7566,'1996-11-11', 5000, NULL,30);
 
 select * from emp_copy;
 
 -- 수정 불가 : salary check 제약조건에 의해서 800 ~ 5000 사이의 값만 입력해야함.
 update emp_copy set salary = 5500 where ename = 'FORD';
 
 -- 가능 : salary 컬럼의 제약조건인 800 ~ 5000 사이의 값이므로 가능.
 update emp_copy set salary = 5000 where ename = 'FORD';
select * from emp_copy;

show index from emp_copy;
show index from dept_copy;
-----
-- check 제약조건 설정 : emp_copy의 dno의 컬럼의 값은 10, 20, 30, 40 중에서 하나를 입력하도록 설정
-- 제약조건 설정 전이므로 가능 
insert into emp_copy
values(9300,'MARY','ANALYST',7566,'1996-09-20', 3500, NULL,50);

select * from emp_copy;
delete from emp_copy where ename = 'MARY';

-- 제약조건 설정 
alter table emp_copy add constraint ck_emp_copy_dno check(dno in (10,20,30,40));

-- 불가 : dno 컬럼의 제약조건에 위배되었기 때문
-- error : Check constraint 'ck_emp_copy_dno' is violated.
insert into emp_copy
values(9300,'MARY','ANALYST',7566,'1996-09-20', 3500, NULL,50);


-- 수정 불가 : dno 컬럼의 제약조건에 위배되었기 때문 
-- error : Check constraint 'ck_emp_copy_dno' is violated.
update emp_copy set dno = 50 where eno = 9200;

desc dept_copy;

-- < 데이터베이스 전체의 제약조건을 확인 >
select * from information_schema.table_constraints
where constraint_schema = 'db01';  -- db 이름 

-- < 테이블의 모든 제약조건 확인 > 
select * from information_schema.table_constraints
where table_name in('emp_copy', 'dept_copy'); -- 테이블 이름 















































































































































































































































































