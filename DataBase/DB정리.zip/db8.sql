
use db01;
---------
-- 5. outer join
-- equi join에서 null 값을 가진 데이터는 출력되지 않음
-- null값을 가지더라도 결과에 나타내고 싶을 때 사용하는 조인 


-- 문제) 사번, 사원명, 직속상관번호, 직속상관명을 확인하시오.
-- self join) 'KING'의 manager는 null 이므로 결과에서 빠져있다.

-- 1. equi join
select s.eno '사번', s.ename '사원명', m.eno'직속상관번호', m.ename '직속상관명'
from employee s , employee m 
where s.manager = m.eno; -- 조인조건

-- 2. inner join
select s.eno,s.ename,m.eno,m.ename
from employee s inner join employee m
on s.manager = m.eno;


-- outer join) 결과값이 null인 값도 포함
select s.eno, s.ename, m.eno, m.ename
from employee s left outer join employee m
on s.manager = m.eno;

-- 문제) 셀프 조인 문제
-- 직속상관보다 먼저 입사한 사원의 사원명 , 사원의 입사일 ,직속상관명 ,직속상관의 입사일을 출력하시오.
-- 1. equi join
select s.ename '사원명', s.hiredate '입사일', o.ename'직속상관명', o.hiredate '입사일'
from employee s , employee o
where s.manager = o.eno
and s.hiredate < o.hiredate;

-- 2. inner join 
select s.ename, s.hiredate, o.ename, o.hiredate
from employee s inner join employee o
on s.manager = o.eno
where s.hiredate < o.hiredate;

----------------------------------
----------------------------------
----------------------------------
-- 서브 쿼리 (sub query) : ★★★★★★★★★★★★★★★★★★중요함
-- 1. 쿼리문 안에 또 다른 쿼리문이 있는 것.
-- main query : 바깥쪽의 쿼리문
-- sub query : 안쪽에 있는 쿼리문.
-- 일반적으로 main query 안에 sub query가 포함된 형태의 쿼리문을 서브쿼리문이라고 부름.

-- 문제) 'SCOTT'보다 많은 월급을 받는 사원의 사원명과 월급을 확인하시오.(단일행 서브쿼리)
-- 서브쿼리를 사용하지 않고 문제를 해결하는 방법
-- 1단계 : 'SCOTT'보다 많은 월급을 구함. -> 3000이라는 결과를 얻음
select ename, salary from employee
where ename = 'SCOTT';

-- 2단계 : 3000보다 많은 월급을 받는 사원의 사원명, 월급을 구함.
select ename, salary from employee
where salary > 3000;

-- < 서브쿼리를 사용하여 문제를 해결하는 방법>
select ename, salary from employee
where salary > (select salary from employee where ename = 'SCOTT');

-- 이 문제를 조인으로 푼다면?
select o.ename, o.salary
from employee s , employee o
where s.salary < o.salary
and s.ename = 'SCOTT';

-- 문제1) 최고급여를 받는 사원의 사원명 ,직무, 급여를 출력하시오 (단일행 서브쿼리문)
select ename, job, max(salary) from employee;	-- 잘못된 결과
-- ename과 job은 14명, 최고급여를 받는 사람은 1명이다.

-- <서브쿼리를 사용하지 않고 문제를 해결>
-- 1단계 : 최고급여를 구한다.	--> 5000
select max(salary) from employee;

-- 2단계 : 5000만원을 받는 사원의 사원명과 , 직무를 구한다.
select ename, job, salary from employee
where salary = 5000;

-- <서브쿼리문을 사용하여 문제를 해결>
select ename, job, salary from employee
where salary = (select max(salary) from employee);

-- 문제2) 30번 부서에서 최저급여를 구하여, 부서별 최저급여가 구한 최저급여보다 큰 부서의 부서번호와 최저급여를 클력하시오.
-- 1단계 - 최저급여 950
select min(salary) from employee
where dno = 30 ;

-- 2단계
select dno , min(salary) from employee
group by dno
having min(salary) > 950;

-- <서브 쿼리문 활용>
select dno, min(salary) from employee
group by dno 
having min(salary) > (select min(salary) from employee where dno = 30);

-- 부서별 최저급여 (검증)
select dno, min(salary) from employee
group by dno;


--------
-- < 서브쿼리 문제를 해결하는 방법 > : 아주 많이 중요함
-- 서브쿼리로 얻어지는 결과의 갯수를 파악 : 1개인지 그 이상인지를 파악
-- 서브쿼리로 얻어지는 결과에 갯수에 따라 두가지로 구분

-- 1. 단일행 서브쿼리문 : 서브쿼리의 결과가 1개일 때 
-- 단일행 서브쿼리에서 사용하는 연산자 : >, >=, <, <=, =, <> 

-- 2. 다중행 서브쿼리문 : 서브쿼리의 결과가 2개 이상일 때 
-- 다중행 서브쿼리에서 사용하는 연산자 : in, any(some), all
-- in : 같을 때 사용 , not in : 같지 않을 때 

---------
-- 문제) 부서별 최저급여를 받는 사원의 사원번호와 사원명, 급여를 출력하시오. (다중행 서브쿼리)
-- 잘못된 쿼리문 : 이 결과는 각부서에서 순서상 첫번째 나오는 사원의 정보를 출력 
select eno, ename, salary ,dno from employee
group by dno;

-- <서브쿼리문으로 문제를 해결>
-- error : subquery returns more than 1 row.
-- 서브쿼리의 결과가 1개보다 많다는 에러가 발생
-- 아래는 단일행 서브쿼리문으로 풀어서 에러가 발생
select eno, ename, salary from employee
where salary = (select min(salary) from employee group by dno);

-- 다중행 서브쿼리로 문제 해결 
select eno, ename, salary from employee
where salary in (select min(salary) from employee group by dno);


select eno, ename, salary from employee
where salary =any (select min(salary) from employee group by dno);
-------------------

-- < 다중행 서브쿼리에서 연산자의 사용 방법 > 
-- 1.  in     : 결과가 같을 때 , in 대신에 =any를 사용해도 됨.(알아만 두고 그냥 in쓰면됨)
-- 	   not in : 결과가 같지 않을 때 

-- 2. any(some) : 서브쿼리의 여러 결과 중에서 한 가지만 만족해도 결과를 출력한다. 
--  <any : 서브쿼리의 결과중에서 최댓값보다 작은 결과를 출력한다.
--  >any : 서브쿼리의 결과중에서 최솟값보다 큰 결과를 출력한다.

-- 3. all : 서브쿼리의 여러 결과를 모두 만족해야 결과를 출력한다.
-- <all : 서브쿼리의 결과중에서 최솟값보다 작은 값를 출력한다.
-- >all : 서브쿼리의 결과중에서 최댓값보다 큰 값를 출력한다.


-- < 다중행 서브쿼리문 응용 연습> 
-- 문제1) 직무가 'SALESMAN'이 아니면서, 
-- 급여가 임의의 'SALESMAN'보다 낮은 사원의 사원번호, 사원명, 직무, 급여를 출력하시오.

select eno, ename, job, salary from employee
where salary <any (select salary from employee where job = 'SALESMAN') and job <> 'SALESMAN';


-- 문제2) 직무가 'SALESMAN'이 아니면서, 
-- 급여가 'SALESMAN'인 사원보다 급여가 작은 사원의 사원번호, 사원명, 직무,급여를 출력하시오.

select eno, ename, job,salary from employee
where salary < all (select salary from employee where job = 'SALESMAN')
and job != 'SALESMAN';

----------
-- <서브쿼리 응용문제 > 
-- 문제1) 'BLAKE'와 동일한 부서에 속한 사원의 사원명, 입사일 ,부서번호를 'BLAKE'는 제외하고 출력하시오.
select ename, hiredate, dno
from employee
where ename <> 'BLAKE' and dno = (select dno from employee where ename = 'BLAKE');

-- 문제2) 사원명에 'K'가 포함된 사원과 같은 부서에서 일하는 사원의 사원번호, 사원명을 출력하시오.
select eno, ename
from employee
where dno in (select dno from employee where ename like '%K%');

-- 문제3) 부서위치가 'DALLAS'인 사원의 이름, 부서번호 직무를 출력하시오. (단일행)
select e.ename, e.dno, e.job
from department d , employee e
where d.dno = e.dno
and loc = 'DALLAS';

select ename, dno, job
from employee
where dno = (select dno from department where loc = 'DALLAS');

-- 문제4) 'RESEARCH'인 부서에서 근무하는 사원의 부서번호, 사원이름 , 직무를 출력하시오.
select dno, ename, job
from employee
where dno = (select dno from department where dname = 'RESEARCH');

-- (다중행 서브쿼리)
-- 문제5) 직무가 'ANALYST'인 사원이 속한 부서와 동일한 부서에서 근무하는 사원의 이름, 직무, 급여를 출력하시오.
select ename, job, salary ,dno
from employee
where dno in (selct



-- (다중행 서브쿼리 + 다중행 서브쿼리)
-- 문제6) 평균급여보다 많은 급여를 받고, 이름에 'M'이 포함된 사원과 같은 부서에서 근무하는 사원의 번호, 이름, 급여를 출력하시오.






























































































































































































