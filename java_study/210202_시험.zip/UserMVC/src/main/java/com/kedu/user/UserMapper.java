package com.kedu.user;

import org.apache.ibatis.annotations.Mapper;

import com.kedu.user.model.UserVO;

@Mapper
public interface UserMapper {
	int insUser(UserVO p);
	UserVO selUser(UserVO p);
}
