package com.kedu.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kedu.user.model.UserVO;

@Controller
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private UserService service;
	
	@GetMapping("/join")
	public void join() {
		
	}
	
	@PostMapping("/join")
	public String join(UserVO p) {
		int result = service.insUser(p);
		
		return "redirect:/user/login";
	}
	
	@GetMapping("/login")
	public void login() {
		
	}
	
	@PostMapping("/login")
	public String login(UserVO p) {
		System.out.println(p.getUid());
		System.out.println(p.getUpw());
		int result = service.selUser(p);
		
		if(result==1) {
			return "redirect:/user/home";
		} else {
			return "redirect:/user/login";
		}
	}
	
	@GetMapping("/home")
	public void home() {
		
	}
	
	
}
