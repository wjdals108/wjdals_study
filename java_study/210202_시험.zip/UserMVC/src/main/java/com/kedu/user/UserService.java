package com.kedu.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kedu.user.model.UserVO;

@Service
public class UserService {
	@Autowired
	private UserMapper mapper;
	
	public int insUser(UserVO p) {
		return mapper.insUser(p);
	}
	
	//1:로그인성공, 2:아이디없음, 3:비밀번호틀림
	public int selUser(UserVO p) {
		UserVO vo = mapper.selUser(p);
		
		if(vo == null) {
			System.out.println("아이디없음");
			return 2; 
		} else if(!p.getUpw().equals(vo.getUpw())) {
			System.out.println("비밀번호틀림");
			return 3;
		}
		System.out.println("로그인성공");
		return 1;
	}
}
