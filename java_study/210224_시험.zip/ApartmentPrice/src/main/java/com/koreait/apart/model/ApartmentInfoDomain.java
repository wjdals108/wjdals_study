package com.koreait.apart.model;

public class ApartmentInfoDomain extends ApartmentInfoEntity{
	private String local_nm;

	public String getLocal_nm() {
		return local_nm;
	}

	public void setLocal_nm(String local_nm) {
		this.local_nm = local_nm;
	}
	
	
}
